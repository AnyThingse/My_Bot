const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("paypal")
    .setDescription("Sends My PaPal If You Want To Donate."),
  async execute(interaction) {
    console.log(interaction);
    await interaction.reply("https://paypal.me/SaifElabd");
  },
};
